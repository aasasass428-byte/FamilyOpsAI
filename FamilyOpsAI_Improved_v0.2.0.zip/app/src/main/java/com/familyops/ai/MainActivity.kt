package com.familyops.ai

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var body: LinearLayout
    private var tab = "Главная"
    private val bg = Color.rgb(246, 248, 252)
    private val ink = Color.rgb(29, 40, 60)
    private val blue = Color.rgb(45, 91, 170)
    private val muted = Color.rgb(104, 117, 137)
    private val green = Color.rgb(34, 128, 95)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("familyops_local_v2", MODE_PRIVATE)
        buildShell()
        showTab("Главная")
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); layoutParams = ViewGroup.LayoutParams(-1, -1) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 14); setBackgroundColor(Color.WHITE) }
        header.addView(TextView(this).apply { text = "FamilyOps AI"; textSize = 25f; setTextColor(ink); setTypeface(null, 1) })
        header.addView(TextView(this).apply { text = "Семейный органайзер · данные на этом телефоне"; textSize = 12f; setTextColor(muted); setPadding(0, 4, 0, 0) })
        root.addView(header)
        body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 16, 18, 20) }
        val scroll = ScrollView(this).apply { addView(body); isFillViewport = true }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.WHITE); setPadding(3, 5, 3, 5) }
        listOf("Главная", "Задачи", "Покупки", "Заметки", "Приватность").forEach { name ->
            nav.addView(TextView(this).apply {
                text = when (name) { "Главная" -> "⌂\nГлавная"; "Задачи" -> "✓\nЗадачи"; "Покупки" -> "▤\nПокупки"; "Заметки" -> "✎\nЗаметки"; else -> "🔒\nЗащита" }
                gravity = Gravity.CENTER; textSize = 11f; setTextColor(if (tab == name) blue else muted); setPadding(2, 7, 2, 7)
                setOnClickListener { showTab(name) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showTab(name: String) { tab = name; buildShell(); when (name) { "Главная" -> home(); "Задачи" -> listScreen("Задачи", "tasks", "Добавить задачу", "Например: забрать посылку"); "Покупки" -> listScreen("Список покупок", "shopping", "Добавить покупку", "Например: молоко"); "Заметки" -> notes(); else -> privacy() } }
    private fun heading(text: String) { body.addView(TextView(this).apply { this.text = text; textSize = 23f; setTextColor(ink); setTypeface(null, 1); setPadding(0, 0, 0, 12) }) }
    private fun sub(text: String) { body.addView(TextView(this).apply { this.text = text; textSize = 14f; setTextColor(muted); setPadding(0, 0, 0, 12) }) }
    private fun card(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 15, 16, 15); setBackgroundColor(Color.WHITE); elevation = 2f; val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 12; layoutParams = p }
    private fun btn(text: String, action: () -> Unit) = Button(this).apply { this.text = text; setOnClickListener { action() } }
    private fun home() {
        heading("Добро пожаловать 👋")
        sub("Организуйте семейные дела — без обязательного облака.")
        val c = card()
        c.addView(TextView(this).apply { text = "СЕГОДНЯ ВАЖНО"; textSize = 12f; setTextColor(blue); setTypeface(null, 1) })
        c.addView(TextView(this).apply { text = "${items("tasks").count { !it.first }} незавершённых задач"; textSize = 20f; setTextColor(ink); setPadding(0, 8, 0, 5) })
        c.addView(TextView(this).apply { text = "${items("shopping").count { !it.first }} позиций в списке покупок"; textSize = 15f; setTextColor(muted) })
        body.addView(c)
        heading("Быстрый доступ")
        body.addView(btn("＋  Добавить задачу") { addItem("tasks", "Новая задача") })
        body.addView(btn("＋  Добавить покупку") { addItem("shopping", "Новая покупка") })
        body.addView(btn("✎  Открыть семейные заметки") { showTab("Заметки") })
        val info = card(); info.addView(TextView(this).apply { text = "🔐 Приватность прежде всего\n\nВ этой версии задачи, покупки и заметки сохраняются локально на этом телефоне. Автоматической передачи данных и геолокации нет."; textSize = 14f; setTextColor(ink) }); body.addView(info)
    }
    private fun listScreen(title: String, key: String, addLabel: String, hint: String) {
        heading(title); sub("Нажмите на пункт, чтобы отметить его выполненным. Долгое нажатие — удалить.")
        body.addView(btn("＋  $addLabel") { addItem(key, hint) })
        val entries = items(key)
        if (entries.isEmpty()) { val c = card(); c.addView(TextView(this).apply { text = "Пока пусто. Добавьте первый пункт."; textSize = 15f; setTextColor(muted) }); body.addView(c) }
        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(12, 8, 8, 8); setBackgroundColor(Color.WHITE); val p = LinearLayout.LayoutParams(-1, -2); p.bottomMargin = 8; layoutParams = p }
            val check = CheckBox(this).apply { isChecked = entry.first; setOnCheckedChangeListener { _, checked -> val current = items(key).toMutableList(); if (index < current.size) { current[index] = checked to current[index].second; saveItems(key, current); showTab(tab) } } }
            row.addView(check)
            val label = TextView(this).apply { text = entry.second; textSize = 16f; setTextColor(if (entry.first) muted else ink); if (entry.first) paintFlags = paintFlags or 0x10; setPadding(4, 10, 4, 10) }
            row.addView(label, LinearLayout.LayoutParams(0, -2, 1f))
            row.setOnLongClickListener { AlertDialog.Builder(this).setTitle("Удалить пункт?").setMessage(entry.second).setNegativeButton("Отмена", null).setPositiveButton("Удалить") { _, _ -> val current = items(key).toMutableList(); if (index < current.size) current.removeAt(index); saveItems(key, current); showTab(tab) }.show(); true }
            body.addView(row)
        }
        if (entries.isNotEmpty()) body.addView(btn("Поделиться списком…") { shareList(title, entries) })
    }
    private fun addItem(key: String, hint: String) {
        val input = EditText(this).apply { setSingleLine(true); this.hint = hint }
        AlertDialog.Builder(this).setTitle(if (key == "tasks") "Новая задача" else "Новая покупка").setView(input).setNegativeButton("Отмена", null).setPositiveButton("Сохранить") { _, _ ->
            val value = input.text.toString().trim(); if (value.isNotEmpty()) { val updated = items(key).toMutableList(); updated.add(false to value); saveItems(key, updated); showTab(tab) }
        }.show()
    }
    private fun items(key: String): List<Pair<Boolean, String>> = prefs.getString(key, "").orEmpty().split("\n").filter { it.isNotBlank() }.mapNotNull { line -> val i = line.indexOf('|'); if (i < 0) null else (line.substring(0, i) == "1") to line.substring(i + 1) }
    private fun saveItems(key: String, data: List<Pair<Boolean, String>>) { prefs.edit().putString(key, data.joinToString("\n") { (if (it.first) "1" else "0") + "|" + it.second.replace("\n", " ") }).apply() }
    private fun shareList(title: String, data: List<Pair<Boolean, String>>) {
        val text = buildString { append("FamilyOps AI — $title\n"); data.forEach { append(if (it.first) "[x] " else "[ ] "); append(it.second); append('\n') }; append("\nПеред отправкой проверьте, что в списке нет личной информации.") }
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, title); putExtra(Intent.EXTRA_TEXT, text) }
        startActivity(Intent.createChooser(intent, "Поделиться выбранным списком"))
    }
    private fun notes() {
        heading("Заметки")
        sub("Заметки сохраняются локально на этом телефоне и не отправляются автоматически.")
        val edit = EditText(this).apply { minLines = 8; gravity = Gravity.TOP; setText(prefs.getString("notes", "")); hint = "Планы, идеи и важные записи…"; textSize = 16f; setPadding(14, 14, 14, 14); setBackgroundColor(Color.WHITE) }
        body.addView(edit, LinearLayout.LayoutParams(-1, -2))
        body.addView(btn("Сохранить заметки") { prefs.edit().putString("notes", edit.text.toString()).apply(); Toast.makeText(this, "Сохранено на этом телефоне", Toast.LENGTH_SHORT).show() })
        body.addView(btn("Поделиться заметками…") { val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, edit.text.toString()) }; startActivity(Intent.createChooser(intent, "Поделиться заметками")) })
    }
    private fun privacy() {
        heading("Приватность и данные")
        val c = card(); c.addView(TextView(this).apply { text = "🔒 Локальное хранение\n\nЗадачи, покупки и заметки хранятся в приложении на этом устройстве. Приложение не использует геолокацию и не синхронизирует данные автоматически. При удалении приложения локальные данные могут быть удалены вместе с ним."; textSize = 15f; setTextColor(ink) }); body.addView(c)
        body.addView(btn("Экспортировать резервную копию текстом…") { exportBackup() })
        body.addView(btn("Удалить все локальные данные…") { AlertDialog.Builder(this).setTitle("Удалить все данные?").setMessage("Будут удалены задачи, покупки и заметки на этом телефоне. Это действие нельзя отменить.").setNegativeButton("Отмена", null).setPositiveButton("Удалить всё") { _, _ -> prefs.edit().clear().apply(); showTab("Главная"); Toast.makeText(this, "Локальные данные удалены", Toast.LENGTH_LONG).show() }.show() })
        sub("Важно: это версия прототипа. Для защиты от доступа к разблокированному телефону и шифрования базы данных нужны дополнительные меры; пока не храните здесь пароли или особо чувствительные сведения.")
    }
    private fun exportBackup() {
        val text = buildString {
            append("FamilyOps AI — локальный экспорт\n\nЗАДАЧИ\n"); items("tasks").forEach { append(if (it.first) "[x] " else "[ ] "); append(it.second); append('\n') }
            append("\nПОКУПКИ\n"); items("shopping").forEach { append(if (it.first) "[x] " else "[ ] "); append(it.second); append('\n') }
            append("\nЗАМЕТКИ\n"); append(prefs.getString("notes", "").orEmpty())
            append("\n\nПроверьте содержимое перед отправкой: экспорт включает заметки.")
        }
        val intent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_SUBJECT, "FamilyOps AI — резервная копия"); putExtra(Intent.EXTRA_TEXT, text) }
        startActivity(Intent.createChooser(intent, "Сохранить или передать резервную копию"))
    }
}
